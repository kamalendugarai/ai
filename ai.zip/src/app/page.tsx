'use client';
import { initializeApp } from 'firebase/app';
import {
  getFirestore,
  collection,
  addDoc,
  // getDocs,
  Firestore
} from 'firebase/firestore';
import ollama from 'ollama/browser';

import { useEffect, useRef, useState } from 'react';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration

export default function Home() {
  const [name, setName] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [price, setPrice] = useState('');
  const fireDb: { current: Firestore | undefined } = useRef();
  const writeToDb = async (db: Firestore, collect: any, data: any) => {
    try {
      const docRef = await addDoc(collection(db, collect), {
        ...data
      });
    } catch (e) {
      console.error('Error adding document: ', e);
    }
  };
  useEffect(() => {
    const firebaseConfig = {
      apiKey: 'AIzaSyDsDPBqRAU_0y0s6D2IOAeI5KFH4udgRn0',
      authDomain: 'local-ai-c0841.firebaseapp.com',
      projectId: 'local-ai-c0841',
      storageBucket: 'local-ai-c0841.appspot.com',
      messagingSenderId: '1078877339410',
      appId: '1:1078877339410:web:0212215e704795ad773dcb'
    };

    // Initialize Firebase
    const app = initializeApp(firebaseConfig);
    fireDb.current = getFirestore(app);
    console.log(fireDb, 'fireDb.current');

    //

    //   console.log("Document written with ID: ", docRef.id);
    //

    // const querySnapshot = await getDocs(collection(db, "users"));
    // querySnapshot.forEach((doc) => {
    //   console.log(`${doc.id} => ${doc.data()}`);
    // });
  }, []);
  return (
    <div>
      <h1>Add Product</h1>
      <form
        onSubmit={async (e) => {
          e.preventDefault();
          console.log(e);
          // console.log(fireDb, 'fireDb');
          console.time('Called Ollama');
          const { response } = await ollama.generate({
            model: 'mistral:latest', //'llama3.1:latest', //'gemma2:latest', //'mistral:latest',
            stream: false,
            prompt: `Extensively findout the allergens from compositional components from ${ingredients}. Do not return any information within brackets. Do not return any explanation. Do not return any group name or such words, characters i.e. protein, proteins, derived, derivatives, allergen, allergens, (, ), [, ] within component name. Instead return list of core allergen components belongs to the group which are associated with that ingredient.`,
            format: 'json'
          });
          await console.log(response.toLowerCase());
          await console.timeEnd('Called Ollama');
        }}
      >
        <div>
          <label>
            Name:
            <input
              type="text"
              placeholder="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            ></input>
          </label>
        </div>
        <div>
          <label>
            Ingredients:
            <input
              type="text"
              placeholder="ingredients"
              value={ingredients}
              onChange={(e) => setIngredients(e.target.value)}
            ></input>
          </label>
        </div>
        <div>
          <label>
            Price:
            <input
              type="text"
              placeholder="name"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            ></input>
          </label>
        </div>
        <input type="submit" value="Submit"></input>
      </form>
    </div>
  );
}
